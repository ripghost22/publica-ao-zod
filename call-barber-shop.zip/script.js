
    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => [...r.querySelectorAll(s)];

    // State
    const AppState = {
      cart: [],
      points: 7,
      profileName: 'Membro Oficial',
      galleryImages: [],
      activeLightboxIndex: 0
    };

    // Helper: Toast Notification
    function showToast(message) {
      const container = $('#toastContainer');
      if (!container) return;
      const t = document.createElement('div');
      t.className = 'toast';
      t.innerHTML = `<span class="toast-dot"></span><span>${message}</span>`;
      container.appendChild(t);
      setTimeout(() => {
        t.style.opacity = '0';
        t.style.transform = 'translateY(10px)';
        setTimeout(() => t.remove(), 300);
      }, 3000);
    }

    // Module 1: Routing & Single Page Navigation
    function initNavigation() {
      try {
        const pages = $$('section[data-page]');
        const links = $$('[data-nav]');
        const mobileMenu = $('#mobileMenu');

        function switchPage(pageId) {
          pages.forEach(p => {
            if (p.getAttribute('data-page') === pageId) {
              p.classList.add('active-page');
            } else {
              p.classList.remove('active-page');
            }
          });

          links.forEach(l => {
            if (l.getAttribute('data-nav') === pageId) {
              l.classList.add('active');
            } else {
              l.classList.remove('active');
            }
          });

          if (mobileMenu) mobileMenu.classList.remove('open');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        window.addEventListener('hashchange', () => {
          const hash = window.location.hash.replace('#', '') || 'home';
          if ($(`section[data-page="${hash}"]`)) {
            switchPage(hash);
          }
        });

        document.addEventListener('click', (e) => {
          const navBtn = e.target.closest('[data-nav]');
          if (navBtn) {
            e.preventDefault();
            const target = navBtn.getAttribute('data-nav');
            window.location.hash = target;
            switchPage(target);
          }
        });

        const initialHash = window.location.hash.replace('#', '') || 'home';
        if ($(`section[data-page="${initialHash}"]`)) {
          switchPage(initialHash);
        }

        // Mobile Burger
        const burger = $('#burgerToggle');
        if (burger && mobileMenu) {
          burger.addEventListener('click', () => {
            mobileMenu.classList.toggle('open');
          });
        }
      } catch (err) {
        console.error('Nav Error:', err);
      }
    }

    // Module 2: Dark Mode & Theme Toggle
    function initTheme() {
      try {
        const btn = $('#btnThemeToggle');
        let currentTheme = 'dark';
        try {
          currentTheme = localStorage.getItem('call_theme') || 'dark';
        } catch(e){}

        if (currentTheme === 'light') {
          document.body.classList.add('light-theme');
        }

        if (btn) {
          btn.addEventListener('click', () => {
            document.body.classList.toggle('light-theme');
            const isLight = document.body.classList.contains('light-theme');
            try {
              localStorage.setItem('call_theme', isLight ? 'light' : 'dark');
            } catch(e){}
            showToast(isLight ? 'Modo Claro ativado' : 'Modo Escuro ativado');
          });
        }
      } catch (err) {
        console.error('Theme Error:', err);
      }
    }

    // Module 3: Cart Drawer & Orders
    function initCart() {
      try {
        const btnOpen = $('#btnOpenCart');
        const btnClose = $('#btnCloseCart');
        const backdrop = $('#cartBackdrop');
        const drawer = $('#cartDrawer');
        const cartList = $('#cartItemList');
        const cartTotal = $('#cartTotalPrice');
        const cartCounter = $('#cartCounter');
        const btnFinish = $('#btnFinishOrder');

        // Load storage
        try {
          const saved = localStorage.getItem('call_cart');
          if (saved) AppState.cart = JSON.parse(saved);
        } catch(e){}

        function openCart() {
          drawer.classList.add('open');
          backdrop.classList.add('open');
        }

        function closeCart() {
          drawer.classList.remove('open');
          backdrop.classList.remove('open');
        }

        if (btnOpen) btnOpen.addEventListener('click', openCart);
        if (btnClose) btnClose.addEventListener('click', closeCart);
        if (backdrop) backdrop.addEventListener('click', closeCart);

        function renderCart() {
          try {
            localStorage.setItem('call_cart', JSON.stringify(AppState.cart));
          } catch(e){}

          const totalQty = AppState.cart.reduce((acc, item) => acc + item.qty, 0);
          if (cartCounter) cartCounter.textContent = totalQty;

          if (AppState.cart.length === 0) {
            cartList.innerHTML = `<p style="color:var(--text-muted); font-size:13px; text-align:center; padding:40px 0;">Seu carrinho está vazio no momento.</p>`;
            if (cartTotal) cartTotal.textContent = 'R$ 0,00';
            return;
          }

          let sum = 0;
          cartList.innerHTML = AppState.cart.map((item, idx) => {
            sum += item.price * item.qty;
            return `
              <div class="cart-item-row">
                <div class="cart-item-img">
                  <img src="${item.img}" alt="${item.name}">
                </div>
                <div class="cart-item-info">
                  <h4>${item.name}</h4>
                  <span>R$ ${item.price.toFixed(2)} cada</span>
                </div>
                <div class="cart-item-controls">
                  <button class="cart-qty-btn" data-qty-change="-1" data-index="${idx}">-</button>
                  <span style="font-size:13px; font-weight:700;">${item.qty}</span>
                  <button class="cart-qty-btn" data-qty-change="1" data-index="${idx}">+</button>
                  <button class="cart-qty-btn" data-remove="${idx}" title="Remover" style="color:#E11D48;">✕</button>
                </div>
              </div>
            `;
          }).join('');

          if (cartTotal) cartTotal.textContent = `R$ ${sum.toFixed(2).replace('.', ',')}`;
        }

        // Event Delegation for Cart Items
        cartList.addEventListener('click', (e) => {
          const qtyBtn = e.target.closest('[data-qty-change]');
          if (qtyBtn) {
            const idx = parseInt(qtyBtn.getAttribute('data-index'), 10);
            const delta = parseInt(qtyBtn.getAttribute('data-qty-change'), 10);
            AppState.cart[idx].qty += delta;
            if (AppState.cart[idx].qty <= 0) {
              AppState.cart.splice(idx, 1);
            }
            renderCart();
            return;
          }

          const removeBtn = e.target.closest('[data-remove]');
          if (removeBtn) {
            const idx = parseInt(removeBtn.getAttribute('data-remove'), 10);
            AppState.cart.splice(idx, 1);
            renderCart();
          }
        });

        // Add to Cart global delegation
        document.addEventListener('click', (e) => {
          const addBtn = e.target.closest('[data-add-cart]');
          if (addBtn) {
            try {
              const data = JSON.parse(addBtn.getAttribute('data-add-cart'));
              const existing = AppState.cart.find(it => it.id === data.id);
              if (existing) {
                existing.qty += 1;
              } else {
                AppState.cart.push({ ...data, qty: 1 });
              }
              renderCart();
              showToast(`"${data.name}" adicionado!`);
              openCart();
            } catch(err) {
              console.error('Error adding item', err);
            }
          }
        });

        // Finish WhatsApp Order
        if (btnFinish) {
          btnFinish.addEventListener('click', () => {
            if (AppState.cart.length === 0) {
              showToast('Adicione ao menos um item ao pedido.');
              return;
            }

            const name = $('#clientName')?.value.trim();
            if (!name) {
              showToast('Por favor, informe seu nome.');
              $('#clientName')?.focus();
              return;
            }

            const notes = $('#clientNotes')?.value.trim() || 'Sem observações';
            const payment = $('#clientPayment')?.value || 'PIX';

            let itemsMsg = '';
            let total = 0;
            AppState.cart.forEach(it => {
              const sub = it.price * it.qty;
              total += sub;
              itemsMsg += `• ${it.qty}x ${it.name} - R$ ${sub.toFixed(2)}\n`;
            });

            const text = 
`*NOVO PEDIDO / AGENDAMENTO - CALL BARBER SHOP*
---------------------------------------
*Cliente:* ${name}
*Forma de Pagamento:* ${payment}
*Preferência / Nota:* ${notes}

*ITENS SELECIONADOS:*
${itemsMsg}
*TOTAL:* R$ ${total.toFixed(2)}
---------------------------------------
_Pedido gerado via site Call Barber Shop (R. Dr. Sebastião Leão, 138)_`;

            const encoded = encodeURIComponent(text);
            const waUrl = `https://wa.me/5551993677019?text=${encoded}`;
            window.open(waUrl, '_blank');

            // Reset cart
            AppState.cart = [];
            renderCart();
            closeCart();
            showToast('Pedido encaminhado com sucesso para o WhatsApp!');
          });
        }

        renderCart();
      } catch (err) {
        console.error('Cart Error:', err);
      }
    }

    // Module 4: Gallery Filters & Lightbox
    function initGallery() {
      try {
        const filterBtns = $$('#galleryFilters .filter-btn');
        const galleryItems = $$('#galleryGrid .masonry-item');
        const lbModal = $('#lightboxModal');
        const lbImg = $('#lbImg');
        const lbClose = $('#lbClose');
        const lbPrev = $('#lbPrev');
        const lbNext = $('#lbNext');

        AppState.galleryImages = galleryItems.map(item => ({
          src: item.getAttribute('data-src'),
          title: item.getAttribute('data-title'),
          category: item.getAttribute('data-cat')
        }));

        filterBtns.forEach(btn => {
          btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const cat = btn.getAttribute('data-filter');

            galleryItems.forEach(item => {
              if (cat === 'all' || item.getAttribute('data-cat') === cat) {
                item.style.display = 'block';
              } else {
                item.style.display = 'none';
              }
            });
          });
        });

        function showLightbox(index) {
          AppState.activeLightboxIndex = index;
          const target = AppState.galleryImages[index];
          if (target && lbImg) {
            lbImg.src = target.src;
            lbImg.alt = target.title;
            lbModal.classList.add('active');
          }
        }

        galleryItems.forEach((item, index) => {
          item.addEventListener('click', () => {
            showLightbox(index);
          });
        });

        function closeLb() {
          if (lbModal) lbModal.classList.remove('active');
        }

        if (lbClose) lbClose.addEventListener('click', closeLb);
        if (lbPrev) lbPrev.addEventListener('click', () => {
          let idx = AppState.activeLightboxIndex - 1;
          if (idx < 0) idx = AppState.galleryImages.length - 1;
          showLightbox(idx);
        });
        if (lbNext) lbNext.addEventListener('click', () => {
          let idx = AppState.activeLightboxIndex + 1;
          if (idx >= AppState.galleryImages.length) idx = 0;
          showLightbox(idx);
        });

        window.addEventListener('keydown', (e) => {
          if (!lbModal.classList.contains('active')) return;
          if (e.key === 'Escape') closeLb();
          if (e.key === 'ArrowLeft') lbPrev.click();
          if (e.key === 'ArrowRight') lbNext.click();
        });
      } catch (err) {
        console.error('Gallery Error:', err);
      }
    }

    // Module 5: Catalog Search & Tabs
    function initCatalogFilters() {
      try {
        const search = $('#catalogSearch');
        const tabs = $$('#catalogCategoryTabs .filter-btn');
        const cards = $$('#productsList .product-card');

        function filterList() {
          const query = search ? search.value.toLowerCase().trim() : '';
          const activeTab = $('#catalogCategoryTabs .filter-btn.active')?.getAttribute('data-cat') || 'all';

          cards.forEach(card => {
            const cat = card.getAttribute('data-category');
            const title = card.querySelector('.product-name')?.textContent.toLowerCase() || '';
            const desc = card.querySelector('.product-desc')?.textContent.toLowerCase() || '';

            const matchesCategory = (activeTab === 'all' || cat === activeTab);
            const matchesQuery = (!query || title.includes(query) || desc.includes(query));

            if (matchesCategory && matchesQuery) {
              card.style.display = 'flex';
            } else {
              card.style.display = 'none';
            }
          });
        }

        tabs.forEach(tab => {
          tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            filterList();
          });
        });

        if (search) {
          search.addEventListener('input', filterList);
        }
      } catch (err) {
        console.error('Catalog Filter Error:', err);
      }
    }

    // Module 6: FAQ Accordion
    function initFAQ() {
      try {
        const items = $$('.faq-item');
        items.forEach(item => {
          const questionBtn = item.querySelector('.faq-question');
          if (questionBtn) {
            questionBtn.addEventListener('click', () => {
              const isOpen = item.classList.contains('open');
              items.forEach(i => i.classList.remove('open'));
              if (!isOpen) {
                item.classList.add('open');
              }
            });
          }
        });
      } catch (err) {
        console.error('FAQ Error:', err);
      }
    }

    // Module 7: Gamification & Profile
    function initGamification() {
      try {
        const display = $('#pointsDisplay');
        const bar = $('#loyaltyBar');
        const btnSim = $('#btnSimulateCheckin');
        const btnSave = $('#btnSaveProfileName');
        const inputName = $('#inputProfileName');
        const nameDisplay = $('#profileUserName');
        const avatarDisplay = $('#userAvatarText');

        // Load profile state
        try {
          const savedPoints = localStorage.getItem('call_points');
          if (savedPoints) AppState.points = parseInt(savedPoints, 10);
          const savedName = localStorage.getItem('call_user_name');
          if (savedName) AppState.profileName = savedName;
        } catch(e){}

        function updateProfileUI() {
          if (display) display.textContent = `${AppState.points} de 10 visitas`;
          if (bar) bar.style.width = `${Math.min((AppState.points / 10) * 100, 100)}%`;
          if (nameDisplay) nameDisplay.textContent = AppState.profileName;
          if (avatarDisplay) {
            avatarDisplay.textContent = AppState.profileName.substring(0, 2).toUpperCase();
          }
        }

        if (btnSim) {
          btnSim.addEventListener('click', () => {
            AppState.points += 1;
            if (AppState.points >= 10) {
              AppState.points = 10;
              showToast('🎉 Parabéns! Você atingiu 10 carimbos e ganhou um corte cortesia!');
            } else {
              showToast(`Carimbo adicionado! Agora você tem ${AppState.points} visitas.`);
            }
            try {
              localStorage.setItem('call_points', AppState.points.toString());
            } catch(e){}
            updateProfileUI();
          });
        }

        if (btnSave && inputName) {
          btnSave.addEventListener('click', () => {
            const val = inputName.value.trim();
            if (val) {
              AppState.profileName = val;
              try {
                localStorage.setItem('call_user_name', val);
              } catch(e){}
              updateProfileUI();
              showToast('Perfil atualizado com sucesso!');
              inputName.value = '';
            }
          });
        }

        updateProfileUI();
      } catch (err) {
        console.error('Gamification Error:', err);
      }
    }

    // Module 8: Onboarding Modal
    function initOnboarding() {
      try {
        const modal = $('#onboardingModal');
        const btnNext = $('#btnOnbNext');
        const btnSkip = $('#btnOnbSkip');
        const btnTrigger = $('#btnTourOnboarding');
        const title = $('#onbTitle');
        const desc = $('#onbDesc');
        const dots = $$('.onb-dot');

        let currentStep = 1;
        const stepsData = [
          {
            title: "Corte com Mestres na Azenha",
            desc: "Localizado na R. Dr. Sebastião Leão, 138. Ambiente clássico, lâmina esterilizada e precisão milimétrica."
          },
          {
            title: "Agendamento & Carrinho Rápido",
            desc: "Escolha cortes, barboterapia e pomadas no nosso catálogo. O pedido vai formatado direto para o WhatsApp!"
          },
          {
            title: "Clube Fidelidade 100% Digital",
            desc: "Acompanhe seus cortes na aba 'Clube Fidelidade' e ganhe recompensas reais a cada visita completada."
          }
        ];

        function renderStep(s) {
          currentStep = s;
          const data = stepsData[s - 1];
          if (title) title.textContent = data.title;
          if (desc) desc.textContent = data.desc;
          dots.forEach(d => {
            d.classList.toggle('active', parseInt(d.getAttribute('data-step'), 10) === s);
          });
          if (btnNext) {
            btnNext.textContent = (s === 3) ? 'Concluir' : 'Próximo ➔';
          }
        }

        function closeModal() {
          modal.classList.remove('active');
          try {
            localStorage.setItem('call_onboarded', 'true');
          } catch(e){}
        }

        if (btnTrigger) {
          btnTrigger.addEventListener('click', () => {
            renderStep(1);
            modal.classList.add('active');
          });
        }

        if (btnSkip) btnSkip.addEventListener('click', closeModal);

        if (btnNext) {
          btnNext.addEventListener('click', () => {
            if (currentStep < 3) {
              renderStep(currentStep + 1);
            } else {
              closeModal();
              showToast('Tour concluído! Aproveite a barbearia.');
            }
          });
        }

        // Auto display if first time
        try {
          const shown = localStorage.getItem('call_onboarded');
          if (!shown) {
            setTimeout(() => {
              renderStep(1);
              modal.classList.add('active');
            }, 800);
          }
        } catch(e){}
      } catch (err) {
        console.error('Onboarding Error:', err);
      }
    }

    // Initialize all components securely
    document.addEventListener('DOMContentLoaded', () => {
      initNavigation();
      initTheme();
      initCart();
      initGallery();
      initCatalogFilters();
      initFAQ();
      initGamification();
      initOnboarding();
    });
  